# Story Idea Generator

## Project Overview
**Story Idea Generator** is a Prompt Engineering project that uses an AI prompt to generate creative and original story ideas based on three user inputs:
- Genre
- Theme
- Main Character Type

The AI produces a complete story concept including:
- Title
- Setting
- Story Idea
- Plot Twist
- Ending

---

## Problem Statement
Writers and students often struggle to come up with fresh story ideas. This project demonstrates how prompt engineering can guide an AI model to generate imaginative and structured story concepts.

## Proposed Solution
A carefully designed prompt instructs the AI to:
1. Accept the user's genre, theme, and character.
2. Generate an original story.
3. Include a title, setting, conflict, plot twist, and ending.

## Prompt
See **Prompt.txt** in this repository.

## Technologies Used
- ChatGPT
- Prompt Engineering
- GitHub
- Microsoft PowerPoint

## Sample Input
- Genre: Science Fiction
- Theme: Sacrifice and Hope
- Main Character Type: Scientist

## Sample Output
**Title:** Echoes of Tomorrow

A scientist discovers a way to send memories into the past to save humanity. She later learns she is a clone created by her future self, and sacrifices her existence to create a better future.

## Repository Structure
```
Story-Idea-Generator/
├── README.md
├── Prompt.txt
├── LICENSE
├── .gitignore
└── Presentation.pptx
```

## Author
**Vaishnavi Panchal**
